﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using ZN_GYM_Management_System.BAL;

namespace ZN_GYM_Management_System.DAL
{
    class DatabaseQuries
    {
        public static SqlConnection GetConnection()
        {
            string strConnection = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlConnection connection = new SqlConnection(strConnection);
            try
            {
                connection.Open();
            }
            catch(Exception)
            {
                MessageBox.Show("Can't Connect");
            }
            return connection;
        }
        //public static DataSet GetDataThroughDataAdapter()
        //{
        //    SqlConnection connection = GetConnection();
        //    string qry = "SELECT * FROM T_Staff;";
        //    SqlCommand command = new SqlCommand(qry, connection);
        //    command.CommandType = CommandType.Text;
        //    SqlDataAdapter adapter = new SqlDataAdapter(command);
        //    DataSet ds = new DataSet();
        //    adapter.Fill(ds, "T_Staff");
        //    return ds;
        //}

        //public static void AddEmployee(Staff staff)
        //{
        //    SqlConnection connection = GetConnection();
        //    string qry = "INSERT INTO T_Staff VALUES(@Employee_ID,@Employee_Name,@CNIC,@Age,@Phone_No,@Address,@Salary,@Date_Of_Hire,@Job_Destination);";
        //    SqlCommand command = new SqlCommand(qry,connection);
        //    command.CommandType = CommandType.Text;
        //    command.Parameters.AddWithValue("@Employee_ID",staff.employee_ID);
        //    command.Parameters.AddWithValue("@Employee_Name", staff.employee_Name);
        //    command.Parameters.AddWithValue("@CNIC", staff.cnic);
        //    command.Parameters.AddWithValue("@Age", staff.age);
        //    command.Parameters.AddWithValue("@Phone_No", staff.phone_No);
        //    command.Parameters.AddWithValue("@Address", staff.address);
        //    command.Parameters.AddWithValue("@Salary", staff.salary);
        //    command.Parameters.AddWithValue("@Date_Of_Hire", staff.date_Of_Hire);
        //    command.Parameters.AddWithValue("@Job_Destination", staff.Job_Destination);
        //    command.ExecuteNonQuery();
        //}

        //-----------------------------------------STAFF------------------------------------------
        public static void AddStaff(int Employee_ID,string Employee_Name,string CNIC,int Age,string Phone_No,string Address,int Salary,string Date_Of_Hire,string Job_Destination)
            {
            SqlConnection con = GetConnection();
            string qry = "INSERT INTO T_Staff VALUES(@Employee_ID,@Employee_Name,@CNIC,@Age,@Phone_No,@Address,@Salary,@Date_Of_Hire,@Job_Destination);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@Employee_ID", Employee_ID);
            cmd.Parameters.AddWithValue("@Employee_Name", Employee_Name);
            cmd.Parameters.AddWithValue("@CNIC",CNIC);
            cmd.Parameters.AddWithValue("@Age", Age);
            cmd.Parameters.AddWithValue("@Phone_No", Phone_No);
            cmd.Parameters.AddWithValue("@Address", Address);
            cmd.Parameters.AddWithValue("@Salary", Salary);
            cmd.Parameters.AddWithValue("@Date_Of_Hire", Date_Of_Hire);
            cmd.Parameters.AddWithValue("@Job_Destination", Job_Destination);
            cmd.ExecuteNonQuery();
        
        }

        //---------------------------------------------------TRAINER-----------------------------------------
        public static void AddTrainer(int Employee_ID,string Employee_Name,string CNIC,int Age,string Phone_No,string Address,int Salary,string Date_Of_Hire,int Experience)
        {
            SqlConnection con = GetConnection();
            string qry = "INSERT INTO T_Trainer VALUES(@Employee_ID,@Employee_Name,@CNIC,@Age,@Phone_No,@Address,@Salary,@Date_Of_Hire,@Experience);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@Employee_ID", Employee_ID);
            cmd.Parameters.AddWithValue("@Employee_Name", Employee_Name);
            cmd.Parameters.AddWithValue("@CNIC", CNIC);
            cmd.Parameters.AddWithValue("@Age", Age);
            cmd.Parameters.AddWithValue("@Phone_No", Phone_No);
            cmd.Parameters.AddWithValue("@Address", Address);
            cmd.Parameters.AddWithValue("@Salary", Salary);
            cmd.Parameters.AddWithValue("@Date_Of_Hire", Date_Of_Hire);
            cmd.Parameters.AddWithValue("@Experience", Experience);
            cmd.ExecuteNonQuery();

        }
        //---------------------------------------------------CUSTOMER----------------------------------------
          public static void AddCustomer(Customerr cus)
        {
            SqlConnection connection = GetConnection();
            string qry = "INSERT INTO T_Customer VALUES(@Customer_ID,@Customer_Name,@Age,@BMI,@Fees,@Joining_Date);";
            SqlCommand command = new SqlCommand(qry,connection);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@Customer_ID",cus.Customer_ID);
            command.Parameters.AddWithValue("@Customer_Name",cus.Customer_Name);
            command.Parameters.AddWithValue("@Age", cus.Age);
            command.Parameters.AddWithValue("@BMI", cus.BMI);
            command.Parameters.AddWithValue("@Fees",cus.Fees);
            command.Parameters.AddWithValue("@Joining_Date", cus.Joining_Date);
            command.ExecuteNonQuery();
        }
          //public static DataSet GetDataForTheCustomer()
          //{
          //    SqlConnection connection = GetConnection();
          //    string qry = "SELECT * FROM T_Customer;";
          //    SqlCommand command = new SqlCommand(qry, connection);
          //    command.CommandType = CommandType.Text;
          //    SqlDataAdapter adapter = new SqlDataAdapter(command);
          //    DataSet ds = new DataSet();
          //    adapter.Fill(ds, "T_Customer");
          //    return ds;
          //}
          public static void UpdateCustomer(Customerr cust)
          {
              SqlConnection connection = GetConnection();
              string qry = "UPDATE T_Customer SET Customer_Name = @Customer_Name,Age = @Age,BMI = @BMI,Fees = @Fees,Joining_Date = @Joining_Date WHERE Customer_ID = @Customer_ID);";
              SqlCommand command = new SqlCommand(qry, connection);
              command.CommandType = CommandType.Text;
              command.Parameters.AddWithValue("@Customer_ID", cust.Customer_ID);
              command.Parameters.AddWithValue("@Customer_Name", cust.Customer_Name);
              command.Parameters.AddWithValue("@Age", cust.Age);
              command.Parameters.AddWithValue("@BMI", cust.BMI);
              command.Parameters.AddWithValue("@Fees", cust.Fees);
              command.Parameters.AddWithValue("@Joining_Date", cust.Joining_Date);
              command.ExecuteNonQuery();
          }

        public static void AddEquipment(Equip equipment)
          {
              SqlConnection connection = GetConnection();
              string qry = "INSERT INTO T_Equipment VALUES(@Machine_ID,@Machine_Name,@Price,@No_Of_Machines,@Installing_Date);";
              SqlCommand command = new SqlCommand(qry, connection);
              command.CommandType = CommandType.Text;
              command.Parameters.AddWithValue("@Machine_ID",equipment.Machine_ID );
              command.Parameters.AddWithValue("@Machine_Name", equipment.Machine_Name);
              command.Parameters.AddWithValue("@Price", equipment.Price);
              command.Parameters.AddWithValue("@No_Of_Machines", equipment.No_Of_Machines);
              command.Parameters.AddWithValue("@Installing_Date",equipment.Installing_Date );
              command.ExecuteNonQuery();
          }
        //public static void UpdateEquip()
        //{
        //    SqlConnection connection = GetConnection();
        //    string qry = "UPDATE T_Equipment SET Machine_Name = '" + + "',Price =  '" + int.Parse(txtPrice.Text) + "', No_Of_Machines = '" + int.Parse(txtNoMachines.Text) + "',Installing_Date = '" + int.Parse(txtInstaling.Text) + "'WHERE Machine_ID = '" + int.Parse(txtMachineID.Text) + "'";
        //    SqlCommand command = new SqlCommand(qry, connection);
        //    command.CommandType = CommandType.Text;
        //    command.Parameters.AddWithValue("@Machine_ID", equipment.Machine_ID);
        //    command.Parameters.AddWithValue("@Machine_Name", equipment.Machine_Name);
        //    command.Parameters.AddWithValue("@Price", equipment.Price);
        //    command.Parameters.AddWithValue("@No_Of_Machines", equipment.No_Of_Machines);
        //    command.Parameters.AddWithValue("@Installing_Date", equipment.Installing_Date);
        //    command.ExecuteNonQuery();
        //}
        public static void AddExpenses(Expenses_Machine expense)
        {
            string qry = "INSERT INTO Expenses VALUES(@Machine_ID,@Price,@Datee);";
            SqlConnection connection = GetConnection();
            SqlCommand command = new SqlCommand(qry, connection);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@Machine_ID", expense.Machine_ID);
            command.Parameters.AddWithValue("@Price", expense.Price);
            command.Parameters.AddWithValue("@Datee", expense.Datee);
            command.ExecuteNonQuery();
        }
        public static void AddPayments(Customer_Payments payme)
        {
            string qry = "INSERT INTO T_Payment VALUES(@Customer_ID,@Price,@Payment_Date);";
            SqlConnection connection = GetConnection();
            SqlCommand command = new SqlCommand(qry, connection);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@Customer_ID", payme.Customer_ID);
            command.Parameters.AddWithValue("@Price", payme.Price);
            command.Parameters.AddWithValue("@Payment_Date",payme.Payment_Date);
            command.ExecuteNonQuery();
        }
        public static void AddAttendance(Customer_Attendance attendence)
        {
            string qry = "INSERT INTO T_Attendance VALUES(@Customer_ID,@Datee,@Statuss);";
            SqlConnection connection = GetConnection();
            SqlCommand command = new SqlCommand(qry, connection);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@Customer_ID",attendence.Customer_ID );
            command.Parameters.AddWithValue("@Datee", attendence.Datee);
            command.Parameters.AddWithValue("@Statuss", attendence.Statuss);
            command.ExecuteNonQuery();
        }
    }
}
