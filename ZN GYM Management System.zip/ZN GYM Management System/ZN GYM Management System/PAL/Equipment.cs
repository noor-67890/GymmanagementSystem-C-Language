﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ZN_GYM_Management_System
{
    public partial class Equipment : Form
    {
        public Equipment()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Machine_ID = int.Parse(txtMachineID.Text);
            string Machine_Name = txtMachineName.Text;
            int Price = int.Parse(txtPrice.Text);
            int No_Of_Machines = int.Parse(txtNoMachines.Text);
            string Installing_Date = txtInstaling.Text;

            BAL.Equip eq = new BAL.Equip(Machine_ID, Machine_Name, Price, No_Of_Machines, Installing_Date);

            try
            {
                DAL.DatabaseQuries.AddEquipment(eq);
                MessageBox.Show("Added Successfully");
            }
            catch (Exception)
            {
                MessageBox.Show("Can't Add");
            }
        }

        private void btnsearchequip_Click(object sender, EventArgs e)
        {
            if (txtSearchMachine.Text != "")
            {

                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Equipment WHERE Machine_ID = '" + txtSearchMachine.Text + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadEquipment.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Please enter here some id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Equipment_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "SELECT * FROM T_Equipment;";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            grdLoadEquipment.DataSource = ds.Tables[0];
        }

        private void btndeleteeqip_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will delete your data. Confirm?", "Delete data", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "DELETE FROM T_Equipment WHERE Machine_ID = '" + txtSearchMachine.Text + "'";

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
            }
            else
            {
                this.Activate();
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Equipment;";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadEquipment.DataSource = ds.Tables[0];
            }
        }

        private void btnupdateequip_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "UPDATE T_Equipment SET Machine_Name = '" + txtMachineName.Text + "',Price =  '" + int.Parse(txtPrice.Text) + "', No_Of_Machines = '" + int.Parse(txtNoMachines.Text) + "',Installing_Date = '" + txtInstaling.Text + "'WHERE Machine_ID = '" + int.Parse(txtMachineID.Text) + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            MessageBox.Show("Updated Successfully");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Main m1 = new Main();
            m1.Show();
        }
    }
}
