﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ZN_GYM_Management_System
{
    public partial class Attendance : Form
    {
        public Attendance()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btncheckattendance_Click(object sender, EventArgs e)
        {
            if (txtCustomerID.Text == "")
            {
                MessageBox.Show("Please Enter Data!");
            }
            else
            {
                string str = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlConnection connection = new SqlConnection(str);
                string q = "if exists (SELECT Customer_ID FROM T_Customer WHERE Customer_ID = '" + int.Parse(txtCustomerID.Text) + "')SELECT Customer_ID FROM T_Customer else SELECT '0';";
                connection.Open();
                SqlCommand cmd = new SqlCommand(q, connection);
                cmd.ExecuteScalar();


                string returnValue = cmd.ExecuteScalar().ToString();
                if (returnValue == "0")
                {
                    MessageBox.Show("Customer Does Not Exist!");
                }
                connection.Close();
                //bool present = false;
                int customer_ID = int.Parse(txtCustomerID.Text);
                string Date = dateTimePicker1.Text;
                string Statuss = txtStatus.Text;
                int Customer_ID = int.Parse(txtCustomerID.Text);
                if (txtCustomerID.Text == "")
                {
                    MessageBox.Show("Please Enter Data!");
                }
                else
                {
                    string strCo = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                    SqlConnection con = new SqlConnection(strCo);
                    string qu = "if exists (SELECT Datee,Customer_ID FROM T_Attendance WHERE Customer_ID = '" + int.Parse(txtCustomerID.Text) + "')SELECT Datee,Customer_ID FROM T_Attendance else SELECT '0';";

                    connection.Open();
                    SqlCommand cm = new SqlCommand(qu, connection);
                    cm.ExecuteScalar(); 


                    string returnValu = cmd.ExecuteScalar().ToString();
                    //if (returnValu == "0") 
                    //{

                        MessageBox.Show("Attendance Marked");


                        BAL.Customer_Attendance a1 = new BAL.Customer_Attendance(Customer_ID, Date, Statuss);
                        DAL.DatabaseQuries.AddAttendance(a1);
                       // MessageBox.Show("Added Successfully");
                    //}

                    //else
                    //{

                       // MessageBox.Show("Attendance Already Marked!");
                    //}
                }
                //if (txtCustomerID.Text == "")
                //{
                //    MessageBox.Show("Please Enter Data!");
                //}
                //else
                //{
                //    string str = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                //    SqlConnection connection = new SqlConnection(str);
                //    string q = "if exists (SELECT Customer_ID FROM T_Customer WHERE Customer_ID = '" + int.Parse(txtCustomerID.Text) + "')SELECT Customer_ID FROM T_Customer else SELECT '0';";
                //    connection.Open();
                //    SqlCommand cmd = new SqlCommand(q, connection);
                //    cmd.ExecuteScalar();


                //    string returnValue = cmd.ExecuteScalar().ToString();
                //    if (returnValue == "0")
                //    {
                //        MessageBox.Show("Customer Does Not Exist!");
                //    }
                //    else
                //    {
                //        string strCo = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                //        SqlConnection con = new SqlConnection(strCo);
                //        connection.Open();
                //        string query = "if exists (SELECT Datee FROM T_Attendance WHERE Datee = '" + dateTimePicker1.Text + "')SELECT Datee FROM T_Attendance else SELECT '0';";
                //        SqlCommand command = new SqlCommand(q, connection);
                //        cmd.ExecuteScalar();


                //        string returnn = cmd.ExecuteScalar().ToString();
                //        if (returnn == "0")
                //        {
                //            BAL.Customer_Attendance a1 = new BAL.Customer_Attendance(customer_ID, Date, Statuss);
                //            try
                //            {
                //                connection.Close();
                //                DAL.DatabaseQuries.AddAttendance(a1);
                //                MessageBox.Show("Attendance Marked");
                //            }
                //            catch (Exception)
                //            {
                //                MessageBox.Show("Can't Mark");
                //            }
                //        }
                //        else
                //        {
                //            MessageBox.Show("Already Marked!!!!!");
                //        }
                //    }
                //}
            }
        }

        private void btnSearchButton_Click(object sender, EventArgs e)
        {
            //int customer_ID = int.Parse(txtCustomerID.Text);
            //if (txtCustomerID.Text == "")
            //{
            //    MessageBox.Show("Please Enter Data!");
            //}
            //else
            //{
            //    string str = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            //    SqlConnection connection = new SqlConnection(str);
            //    string q = "if exists (SELECT Customer_ID FROM T_Customer WHERE Customer_ID = '" + int.Parse(txtCustomerID.Text) + "')SELECT Customer_ID FROM T_Customer else SELECT '0';";
            //    connection.Open();
            //    SqlCommand cmd = new SqlCommand(q, connection);
            //    cmd.ExecuteScalar();


            //    string returnValue = cmd.ExecuteScalar().ToString();
            //    if (returnValue == "0")
            //    {
            //        MessageBox.Show("Customer Does Not Exist!");
            //    }
            //    else
            //    {
            //        MessageBox.Show("Customer Exists,Enter The Values");
            //    }
            //}
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Main m1 = new Main();
            m1.Show();
        }

        private void btnattendanceshow_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "SELECT * FROM T_Attendance;";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            grdLoadAttendacne.DataSource = ds.Tables[0];
        }
    }
}
