﻿namespace ZN_GYM_Management_System
{
    partial class Equipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Equipment));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtMachineID = new System.Windows.Forms.TextBox();
            this.txtMachineName = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtNoMachines = new System.Windows.Forms.TextBox();
            this.txtInstaling = new System.Windows.Forms.TextBox();
            this.btnupdateequip = new System.Windows.Forms.Button();
            this.btndeleteeqip = new System.Windows.Forms.Button();
            this.btnsearchequip = new System.Windows.Forms.Button();
            this.txtSearchMachine = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.grdLoadEquipment = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdLoadEquipment)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(87, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Equipment";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Machine ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Machine Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 232);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 287);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(201, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "Number of Machine";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(28, 350);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(160, 23);
            this.label6.TabIndex = 5;
            this.label6.Text = "Installing Date";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(31, 434);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 37);
            this.button1.TabIndex = 6;
            this.button1.Text = "Add Equipment";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtMachineID
            // 
            this.txtMachineID.Location = new System.Drawing.Point(257, 120);
            this.txtMachineID.Name = "txtMachineID";
            this.txtMachineID.Size = new System.Drawing.Size(189, 20);
            this.txtMachineID.TabIndex = 7;
            // 
            // txtMachineName
            // 
            this.txtMachineName.Location = new System.Drawing.Point(257, 180);
            this.txtMachineName.Name = "txtMachineName";
            this.txtMachineName.Size = new System.Drawing.Size(189, 20);
            this.txtMachineName.TabIndex = 8;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(257, 232);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(189, 20);
            this.txtPrice.TabIndex = 9;
            // 
            // txtNoMachines
            // 
            this.txtNoMachines.Location = new System.Drawing.Point(257, 292);
            this.txtNoMachines.Name = "txtNoMachines";
            this.txtNoMachines.Size = new System.Drawing.Size(189, 20);
            this.txtNoMachines.TabIndex = 10;
            // 
            // txtInstaling
            // 
            this.txtInstaling.Location = new System.Drawing.Point(257, 343);
            this.txtInstaling.Name = "txtInstaling";
            this.txtInstaling.Size = new System.Drawing.Size(189, 20);
            this.txtInstaling.TabIndex = 11;
            // 
            // btnupdateequip
            // 
            this.btnupdateequip.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdateequip.Location = new System.Drawing.Point(231, 434);
            this.btnupdateequip.Name = "btnupdateequip";
            this.btnupdateequip.Size = new System.Drawing.Size(215, 37);
            this.btnupdateequip.TabIndex = 12;
            this.btnupdateequip.Text = "Update Equipment";
            this.btnupdateequip.UseVisualStyleBackColor = true;
            this.btnupdateequip.Click += new System.EventHandler(this.btnupdateequip_Click);
            // 
            // btndeleteeqip
            // 
            this.btndeleteeqip.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndeleteeqip.Location = new System.Drawing.Point(809, 434);
            this.btndeleteeqip.Name = "btndeleteeqip";
            this.btndeleteeqip.Size = new System.Drawing.Size(202, 37);
            this.btndeleteeqip.TabIndex = 13;
            this.btndeleteeqip.Text = "Delete Equipment";
            this.btndeleteeqip.UseVisualStyleBackColor = true;
            this.btndeleteeqip.Click += new System.EventHandler(this.btndeleteeqip_Click);
            // 
            // btnsearchequip
            // 
            this.btnsearchequip.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchequip.Location = new System.Drawing.Point(584, 434);
            this.btnsearchequip.Name = "btnsearchequip";
            this.btnsearchequip.Size = new System.Drawing.Size(210, 37);
            this.btnsearchequip.TabIndex = 14;
            this.btnsearchequip.Text = "Search Equipment";
            this.btnsearchequip.UseVisualStyleBackColor = true;
            this.btnsearchequip.Click += new System.EventHandler(this.btnsearchequip_Click);
            // 
            // txtSearchMachine
            // 
            this.txtSearchMachine.Location = new System.Drawing.Point(809, 309);
            this.txtSearchMachine.Name = "txtSearchMachine";
            this.txtSearchMachine.Size = new System.Drawing.Size(202, 20);
            this.txtSearchMachine.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(594, 309);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 23);
            this.label7.TabIndex = 16;
            this.label7.Text = "Machine ID";
            // 
            // grdLoadEquipment
            // 
            this.grdLoadEquipment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.grdLoadEquipment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdLoadEquipment.Location = new System.Drawing.Point(598, 12);
            this.grdLoadEquipment.Name = "grdLoadEquipment";
            this.grdLoadEquipment.Size = new System.Drawing.Size(557, 260);
            this.grdLoadEquipment.TabIndex = 17;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(988, 511);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 38);
            this.button2.TabIndex = 18;
            this.button2.Text = "Exit to menu";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Equipment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1159, 592);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.grdLoadEquipment);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtSearchMachine);
            this.Controls.Add(this.btnsearchequip);
            this.Controls.Add(this.btndeleteeqip);
            this.Controls.Add(this.btnupdateequip);
            this.Controls.Add(this.txtInstaling);
            this.Controls.Add(this.txtNoMachines);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtMachineName);
            this.Controls.Add(this.txtMachineID);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Equipment";
            this.Text = "Equipment";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Equipment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdLoadEquipment)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtMachineID;
        private System.Windows.Forms.TextBox txtMachineName;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtNoMachines;
        private System.Windows.Forms.TextBox txtInstaling;
        private System.Windows.Forms.Button btnupdateequip;
        private System.Windows.Forms.Button btndeleteeqip;
        private System.Windows.Forms.Button btnsearchequip;
        private System.Windows.Forms.TextBox txtSearchMachine;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView grdLoadEquipment;
        private System.Windows.Forms.Button button2;
    }
}