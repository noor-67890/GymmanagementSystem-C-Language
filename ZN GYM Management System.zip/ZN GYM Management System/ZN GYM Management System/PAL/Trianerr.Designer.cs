﻿namespace ZN_GYM_Management_System.PAL
{
    partial class Form_Trainer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSearchEmployees = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.grdLoadEmployees = new System.Windows.Forms.DataGridView();
            this.txtExperience = new System.Windows.Forms.TextBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.txtPhone_No = new System.Windows.Forms.TextBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtTrainerName = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtAgeTrainer = new System.Windows.Forms.TextBox();
            this.txtTCNIC = new System.Windows.Forms.TextBox();
            this.txtTrainerID = new System.Windows.Forms.TextBox();
            this.btnsearchemp = new System.Windows.Forms.Button();
            this.btndeleteemp = new System.Windows.Forms.Button();
            this.btnupdateemp = new System.Windows.Forms.Button();
            this.btnaddemp = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCNIC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdLoadEmployees)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSearchEmployees
            // 
            this.txtSearchEmployees.Location = new System.Drawing.Point(792, 366);
            this.txtSearchEmployees.Name = "txtSearchEmployees";
            this.txtSearchEmployees.Size = new System.Drawing.Size(187, 20);
            this.txtSearchEmployees.TabIndex = 57;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(620, 366);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 20);
            this.label12.TabIndex = 56;
            this.label12.Text = "Trainer ID";
            // 
            // grdLoadEmployees
            // 
            this.grdLoadEmployees.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.grdLoadEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdLoadEmployees.Location = new System.Drawing.Point(453, 28);
            this.grdLoadEmployees.Name = "grdLoadEmployees";
            this.grdLoadEmployees.Size = new System.Drawing.Size(640, 326);
            this.grdLoadEmployees.TabIndex = 55;
            // 
            // txtExperience
            // 
            this.txtExperience.Location = new System.Drawing.Point(233, 347);
            this.txtExperience.Name = "txtExperience";
            this.txtExperience.Size = new System.Drawing.Size(189, 20);
            this.txtExperience.TabIndex = 54;
            // 
            // txtSalary
            // 
            this.txtSalary.Location = new System.Drawing.Point(233, 257);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(189, 20);
            this.txtSalary.TabIndex = 53;
            // 
            // txtPhone_No
            // 
            this.txtPhone_No.Location = new System.Drawing.Point(233, 175);
            this.txtPhone_No.Name = "txtPhone_No";
            this.txtPhone_No.Size = new System.Drawing.Size(189, 20);
            this.txtPhone_No.TabIndex = 52;
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(233, 298);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(189, 20);
            this.txtDate.TabIndex = 51;
            // 
            // txtTrainerName
            // 
            this.txtTrainerName.Location = new System.Drawing.Point(233, 63);
            this.txtTrainerName.Name = "txtTrainerName";
            this.txtTrainerName.Size = new System.Drawing.Size(189, 20);
            this.txtTrainerName.TabIndex = 50;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(233, 215);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(189, 20);
            this.txtAddress.TabIndex = 49;
            // 
            // txtAgeTrainer
            // 
            this.txtAgeTrainer.Location = new System.Drawing.Point(233, 139);
            this.txtAgeTrainer.Name = "txtAgeTrainer";
            this.txtAgeTrainer.Size = new System.Drawing.Size(189, 20);
            this.txtAgeTrainer.TabIndex = 48;
            // 
            // txtTCNIC
            // 
            this.txtTCNIC.Location = new System.Drawing.Point(233, 101);
            this.txtTCNIC.Name = "txtTCNIC";
            this.txtTCNIC.Size = new System.Drawing.Size(189, 20);
            this.txtTCNIC.TabIndex = 47;
            // 
            // txtTrainerID
            // 
            this.txtTrainerID.Location = new System.Drawing.Point(233, 28);
            this.txtTrainerID.Name = "txtTrainerID";
            this.txtTrainerID.Size = new System.Drawing.Size(189, 20);
            this.txtTrainerID.TabIndex = 46;
            // 
            // btnsearchemp
            // 
            this.btnsearchemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchemp.Location = new System.Drawing.Point(574, 450);
            this.btnsearchemp.Name = "btnsearchemp";
            this.btnsearchemp.Size = new System.Drawing.Size(182, 44);
            this.btnsearchemp.TabIndex = 45;
            this.btnsearchemp.Text = "Search Trainer";
            this.btnsearchemp.UseVisualStyleBackColor = true;
            this.btnsearchemp.Click += new System.EventHandler(this.btnsearchemp_Click);
            // 
            // btndeleteemp
            // 
            this.btndeleteemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndeleteemp.Location = new System.Drawing.Point(823, 450);
            this.btndeleteemp.Name = "btndeleteemp";
            this.btndeleteemp.Size = new System.Drawing.Size(213, 44);
            this.btndeleteemp.TabIndex = 44;
            this.btndeleteemp.Text = "Delete Trainer";
            this.btndeleteemp.UseVisualStyleBackColor = true;
            this.btndeleteemp.Click += new System.EventHandler(this.btndeleteemp_Click);
            // 
            // btnupdateemp
            // 
            this.btnupdateemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdateemp.Location = new System.Drawing.Point(233, 429);
            this.btnupdateemp.Name = "btnupdateemp";
            this.btnupdateemp.Size = new System.Drawing.Size(189, 26);
            this.btnupdateemp.TabIndex = 43;
            this.btnupdateemp.Text = "Update Trainer";
            this.btnupdateemp.UseVisualStyleBackColor = true;
            this.btnupdateemp.Click += new System.EventHandler(this.btnupdateemp_Click);
            // 
            // btnaddemp
            // 
            this.btnaddemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddemp.Location = new System.Drawing.Point(35, 429);
            this.btnaddemp.Name = "btnaddemp";
            this.btnaddemp.Size = new System.Drawing.Size(188, 26);
            this.btnaddemp.TabIndex = 42;
            this.btnaddemp.Text = "Add Trainer";
            this.btnaddemp.UseVisualStyleBackColor = true;
            this.btnaddemp.Click += new System.EventHandler(this.btnaddemp_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(31, 347);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(155, 20);
            this.label11.TabIndex = 41;
            this.label11.Text = "Experience_Years\r\n";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(45, 298);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 24);
            this.label9.TabIndex = 39;
            this.label9.Text = "Date of Hire";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(-161, 255);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 24);
            this.label8.TabIndex = 38;
            this.label8.Text = "Salary";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(-163, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 24);
            this.label7.TabIndex = 37;
            this.label7.Text = "Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(31, 175);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 24);
            this.label6.TabIndex = 36;
            this.label6.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(-162, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 24);
            this.label5.TabIndex = 35;
            this.label5.Text = "Age";
            // 
            // txtCNIC
            // 
            this.txtCNIC.AutoSize = true;
            this.txtCNIC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCNIC.Location = new System.Drawing.Point(-162, 94);
            this.txtCNIC.Name = "txtCNIC";
            this.txtCNIC.Size = new System.Drawing.Size(58, 24);
            this.txtCNIC.TabIndex = 34;
            this.txtCNIC.Text = "CNIC";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 24);
            this.label3.TabIndex = 33;
            this.label3.Text = "Trainer Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(54, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 24);
            this.label2.TabIndex = 32;
            this.label2.Text = "Trainer ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-73, -34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 31);
            this.label1.TabIndex = 31;
            this.label1.Text = "EMPLOYEE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(64, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 24);
            this.label4.TabIndex = 62;
            this.label4.Text = "Age";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(64, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 24);
            this.label14.TabIndex = 61;
            this.label14.Text = "CNIC";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(54, 215);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 24);
            this.label15.TabIndex = 63;
            this.label15.Text = "Address";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(45, 257);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 24);
            this.label16.TabIndex = 64;
            this.label16.Text = "Salary";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1018, 532);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 45);
            this.button1.TabIndex = 65;
            this.button1.Text = "Exit to menu";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form_Trainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1155, 605);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtSearchEmployees);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.grdLoadEmployees);
            this.Controls.Add(this.txtExperience);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.txtPhone_No);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.txtTrainerName);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtAgeTrainer);
            this.Controls.Add(this.txtTCNIC);
            this.Controls.Add(this.txtTrainerID);
            this.Controls.Add(this.btnsearchemp);
            this.Controls.Add(this.btndeleteemp);
            this.Controls.Add(this.btnupdateemp);
            this.Controls.Add(this.btnaddemp);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCNIC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form_Trainer";
            this.Text = "Trianerr";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form_Trainer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdLoadEmployees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearchEmployees;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView grdLoadEmployees;
        private System.Windows.Forms.TextBox txtExperience;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.TextBox txtPhone_No;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtTrainerName;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtAgeTrainer;
        private System.Windows.Forms.TextBox txtTCNIC;
        private System.Windows.Forms.TextBox txtTrainerID;
        private System.Windows.Forms.Button btnsearchemp;
        private System.Windows.Forms.Button btndeleteemp;
        private System.Windows.Forms.Button btnupdateemp;
        private System.Windows.Forms.Button btnaddemp;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label txtCNIC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button1;
    }
}