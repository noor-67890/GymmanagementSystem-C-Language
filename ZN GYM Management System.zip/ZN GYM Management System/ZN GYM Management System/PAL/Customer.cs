﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZN_GYM_Management_System.DAL;
using System.Data.SqlClient;

namespace ZN_GYM_Management_System
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtid.Text == "" || txtname.Text == "" || txtage.Text == "" || txtbmI.Text == "" || txtfees.Text == "" || txtjoiningdate.Text == "")
            {
                MessageBox.Show("Missing Values");
            }
            else
            {


                int customer_ID = int.Parse(txtid.Text);
                if (txtid.Text == "")
                {
                    MessageBox.Show("Please Enter Data!");
                }
                else
                {
                    string str = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                    SqlConnection connection = new SqlConnection(str);
                    string q = "if exists (SELECT Customer_ID FROM T_Customer WHERE Customer_ID = '" + int.Parse(txtid.Text) + "')SELECT Customer_ID FROM T_Customer else SELECT '0';";
                    connection.Open();
                    SqlCommand cmd = new SqlCommand(q, connection);
                    cmd.ExecuteScalar();


                    string returnValue = cmd.ExecuteScalar().ToString();
                    if (returnValue == "0")
                    {

                        MessageBox.Show("Customer Exists,Enter The Values");
                        int Customer_ID = int.Parse(txtid.Text);
                        string Customer_Name = txtname.Text;
                        int Age = int.Parse(txtage.Text);
                        int BMI = int.Parse(txtbmI.Text);
                        int Fees = int.Parse(txtfees.Text);
                        string Joining_Date = txtjoiningdate.Text;
                        BAL.Customerr customer = new BAL.Customerr(Customer_ID, Customer_Name, Age, BMI, Fees, Joining_Date);

                        try
                        {
                            DAL.DatabaseQuries.AddCustomer(customer);
                            MessageBox.Show("Added Successfully");
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("Can't add");
                        }
                    }

                    else
                    {

                        MessageBox.Show("Customer Already Exists!");
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void bynupdatecust_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "UPDATE T_Customer SET Customer_ID = '" + int.Parse(txtid.Text) + "',Customer_Name =  '" + txtname.Text + "', Age = '" + int.Parse(txtage.Text) + "',BMI = '" + int.Parse(txtbmI.Text) + "',Fees = '" + int.Parse(txtfees.Text) + "',Joining_Date = '" + txtjoiningdate.Text + "'WHERE Customer_ID = '" + int.Parse(txtid.Text)+ "'";

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);

            try
            { 
               MessageBox.Show("Updated Successfully");
            }
            catch (Exception)
            {
                MessageBox.Show("Can't update");
            }
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnsearchcust_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text != "")
            {

                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Customer WHERE Customer_ID = '" + txtSearch.Text + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadCustomer.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Please enter here some id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "SELECT * FROM T_Customer;";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            grdLoadCustomer.DataSource = ds.Tables[0];
        }

        private void btndeletecust_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will delete your data. Confirm?", "Delete data", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "DELETE FROM T_Customer WHERE Customer_ID = " + txtSearch.Text + "";

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
            }
            else
            {
                this.Activate();
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Customer;";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadCustomer.DataSource = ds.Tables[0];
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
                this.Close();
                Main m1 = new Main();
                m1.Show();
            
        }
    }
}
