﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ZN_GYM_Management_System
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void btndeleteemp_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will delete your data. Confirm?", "Delete data", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "DELETE FROM T_Staff WHERE Employee_ID = '" + txtSearchEmployees.Text + "'";

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
            }
            else
            {
                this.Activate();
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Staff;";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadEmployees.DataSource = ds.Tables[0];
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnaddemp_Click(object sender, EventArgs e)
        {

                int Employee_ID = int.Parse(txtEmployeeID.Text);
                string Employee_Name = txtEmployeeName.Text;
                string CNIC = txtcn.Text;
                int Age = int.Parse(txtAge.Text);
                string Phone_No = txtPhone_No.Text;
                string Address = txtAddress.Text;
                int Salary = int.Parse(txtSalary.Text);
                string Date_Of_Hire = txtDate.Text;
                string Job_Desgination = txtJob_Degination.Text;
                //BAL.Staff s1 = new BAL.Staff(Employee_ID, Employee_Name, CNIC, Age, Phone_No, Address, Salary, Date_Of_Hire, Job_Desgination);
                try
                {
                    DAL.DatabaseQuries.AddStaff(Employee_ID, Employee_Name, CNIC, Age, Phone_No, Address, Salary, Date_Of_Hire, Job_Desgination);
                    MessageBox.Show("Added Successfully");
                }
                catch (Exception)
                {
                    MessageBox.Show("Can't add");
                }
           // }
        }
            //else if (cmbemployeetype.Items.Equals("Trainer"))
            //{
            //    int Employee_ID = int.Parse(txtEmployeeID.Text);
            //    string Employee_Name = txtEmployeeName.Text;
            //    string CNIC = txtCNIC.Text;
            //    int Age = int.Parse(txtAge.Text);
            //    string Phone_No = txtPhone_No.Text;
            //    string Address = txtAddress.Text;
            //    int Salary = int.Parse(txtSalary.Text);
            //    string Data_Of_Hire = txtDate.Text;
            //    string Job_Desgination = txtJob_Degination.Text;
            //    int Experience = int.Parse(txtExperience.Text);
            //    BAL.Staff s1 = new BAL.Staff(Employee_ID, Employee_Name, CNIC, Age, Phone_No, Address, Salary, Data_Of_Hire, Job_Desgination);
            //    //try
            //    //{
            //    DAL.DatabaseQuries.AddStaff(s1);
            //    MessageBox.Show("Added Successfully");
            //    //}
            //    //catch (Exception)
            //    //{
            //    //    MessageBox.Show("Can't add");
            //    //}
    //}

           
    //    }

        private void btnupdateemp_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "UPDATE T_Staff SET Employee_Name = '" + txtEmployeeName.Text + "',CNIC =  '" + txtcn.Text + "', Age = '" + int.Parse(txtAge.Text) + "',Phone_No = '" + txtPhone_No.Text + "',Addresss = '" + txtAddress.Text + "',Salary = '" + int.Parse(txtSalary.Text) + "',Date_Of_Hire = '" + txtDate.Text + "',Job_Designation = '" + txtJob_Degination.Text + "'WHERE Employee_ID = '" + int.Parse(txtEmployeeID.Text) + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            MessageBox.Show("Updated Successfully");

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnsearchemp_Click(object sender, EventArgs e)
        {
            if (txtSearchEmployees.Text != "")
            {

                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Staff WHERE Employee_ID = '" + txtSearchEmployees.Text + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadEmployees.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Please enter here some id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
            Main m1 = new Main();
            m1.Show();
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "SELECT * FROM T_Staff;";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            grdLoadEmployees.DataSource = ds.Tables[0];
        }
    }
}
