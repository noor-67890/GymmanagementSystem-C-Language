﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZN_GYM_Management_System.PAL;

namespace ZN_GYM_Management_System
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            Customer c1 = new Customer();
            c1.Show();
            this.Hide();
        }

        private void btnaddstaff_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Show();
            this.Hide();
        }

        private void btnequipment_Click(object sender, EventArgs e)
        {
            Equipment equipmentss = new Equipment();
            equipmentss.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            Expenses exp = new Expenses();
            exp.Show();
            this.Hide();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            Payments pay = new Payments();
            pay.Show();
            this.Hide();
        }

        private void btnTrainer_Click(object sender, EventArgs e)
        {
            Form_Trainer tra = new Form_Trainer();
            tra.Show();
            this.Hide();
        }

        private void btnvieattendance_Click(object sender, EventArgs e)
        {
            Attendance a1 = new Attendance();
            a1.Show();
            this.Hide();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Log OUT !! Confirm?","LOG OUT",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning)==DialogResult.OK)
            {
                this.Close();
                Login lg = new Login();
                lg.Show();
            }
        }
    }
}
