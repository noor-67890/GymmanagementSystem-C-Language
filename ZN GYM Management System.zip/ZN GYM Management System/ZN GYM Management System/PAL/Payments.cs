﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ZN_GYM_Management_System
{
    public partial class Payments : Form
    {
        public Payments()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int customer_ID = int.Parse(txtCustomerID.Text);
            if (txtCustomerID.Text == "")
            {
                MessageBox.Show("Please Enter Data!");
            }
            else
            {
                string str = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlConnection connection = new SqlConnection(str);
                string q = "if exists (SELECT Customer_ID FROM T_Customer WHERE Customer_ID = '" + int.Parse(txtCustomerID.Text) + "')SELECT Customer_ID FROM T_Customer else SELECT '0';";
                connection.Open();
                SqlCommand cmd = new SqlCommand(q, connection);
                cmd.ExecuteScalar();


                string returnValue = cmd.ExecuteScalar().ToString();
                if (returnValue == "0")
                {
                    MessageBox.Show("Customer Does Not Exist!");
                }
                else
                {
                    MessageBox.Show("Customer Exists,Enter The Values");
                }
            }
        }

        private void btnaddpayment_Click(object sender, EventArgs e)
        {
            int Customer_ID = int.Parse(txtCustomerID.Text);
            int Price = int.Parse(txtPrice.Text);
            string Payment_Date = txtPayment_Date.Text;

            BAL.Customer_Payments payment = new BAL.Customer_Payments(Customer_ID,Price,Payment_Date);
            //try
            //{
                DAL.DatabaseQuries.AddPayments(payment);
                MessageBox.Show("Added Sucessfully");
            //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Can't Add");
            //}
        }

        private void btndisplaypay_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "SELECT * FROM T_Payment;";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            grdLoadPayments.DataSource = ds.Tables[0];
        }

        private void Payments_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "SELECT * FROM T_Payment;";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            grdLoadPayments.DataSource = ds.Tables[0];
        }

        private void btnsearchpay_Click(object sender, EventArgs e)
        {
            if (txtSearchPayment.Text != "")
            {

                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Payment WHERE Payment_Date = '" + txtSearchPayment.Text + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadPayments.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Please enter here some id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Main m1 = new Main();
            m1.Show();
        }
        }
    }

