﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ZN_GYM_Management_System.PAL
{
    public partial class Form_Trainer : Form
    {
        public Form_Trainer()
        {
            InitializeComponent();
        }

        private void btnupdateemp_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "UPDATE T_Trainer SET Employee_Name = '" + txtTrainerName.Text + "',CNIC =  '" + txtTCNIC.Text + "', Age = '" + int.Parse(txtAgeTrainer.Text) + "',Phone_No = '" + txtPhone_No.Text + "',Addresss = '" + txtAddress.Text + "',Salary = '" + int.Parse(txtSalary.Text) + "',Date_Of_Hire = '" + txtDate.Text + "',Experience  = '" + int.Parse(txtExperience.Text) + "'WHERE Employee_ID = '" + int.Parse(txtTrainerID.Text) + "'";

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            MessageBox.Show("Updated Successfully");
        }

        private void btnaddemp_Click(object sender, EventArgs e)
        {
            int Employee_ID = int.Parse(txtTrainerID.Text);
            string Employee_Name = txtTrainerName.Text;
            string CNIC = txtTCNIC.Text;
            int Age = int.Parse(txtAgeTrainer.Text);
            string Phone_No = txtPhone_No.Text;
            string Address = txtAddress.Text;
            int Salary = int.Parse(txtSalary.Text);
            string Date_Of_Hire = txtDate.Text;
            int Experience = int.Parse(txtExperience.Text);
            //BAL.Staff s1 = new BAL.Staff(Employee_ID, Employee_Name, CNIC, Age, Phone_No, Address, Salary, Date_Of_Hire, Job_Desgination);
            try
            {
                DAL.DatabaseQuries.AddTrainer(Employee_ID, Employee_Name, CNIC, Age, Phone_No, Address, Salary, Date_Of_Hire, Experience);
                MessageBox.Show("Added Successfully");
            }
            catch (Exception)
            {
                MessageBox.Show("Can't add");
            }
        }

        private void Form_Trainer_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "SELECT * FROM T_Trainer;";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            grdLoadEmployees.DataSource = ds.Tables[0];
        }

        private void btnsearchemp_Click(object sender, EventArgs e)
        {
            if (txtSearchEmployees.Text != "")
            {

                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Trainer WHERE Employee_ID = '" + txtSearchEmployees.Text + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadEmployees.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Please enter here some id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btndeleteemp_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will delete your data. Confirm?", "Delete data", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "DELETE FROM T_Trainer WHERE Employee_ID = '" + txtSearchEmployees.Text + "'";

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
            }
            else
            {
                this.Activate();
                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM T_Trainer WHERE Employee_ID = '" + txtSearchEmployees.Text + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadEmployees.DataSource = ds.Tables[0];
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Main m1 = new Main();
            m1.Show();
        }
    }
}
