﻿namespace ZN_GYM_Management_System
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer));
            this.btnaddmember = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtage = new System.Windows.Forms.TextBox();
            this.txtbmI = new System.Windows.Forms.TextBox();
            this.txtfees = new System.Windows.Forms.TextBox();
            this.txtjoiningdate = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.bynupdatecust = new System.Windows.Forms.Button();
            this.btndeletecust = new System.Windows.Forms.Button();
            this.btnsearchcust = new System.Windows.Forms.Button();
            this.grdLoadCustomer = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdLoadCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // btnaddmember
            // 
            this.btnaddmember.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddmember.Location = new System.Drawing.Point(33, 426);
            this.btnaddmember.Name = "btnaddmember";
            this.btnaddmember.Size = new System.Drawing.Size(229, 44);
            this.btnaddmember.TabIndex = 1;
            this.btnaddmember.Text = "Add Member";
            this.btnaddmember.UseVisualStyleBackColor = true;
            this.btnaddmember.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(164, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Customer ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(164, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "Customer Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(209, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Age";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(209, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 23);
            this.label4.TabIndex = 5;
            this.label4.Text = "BMI";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(210, 320);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 23);
            this.label5.TabIndex = 6;
            this.label5.Text = "Fees";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(191, 363);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 23);
            this.label6.TabIndex = 7;
            this.label6.Text = "Joining Date";
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(371, 112);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(166, 20);
            this.txtid.TabIndex = 8;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(371, 158);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(166, 20);
            this.txtname.TabIndex = 9;
            // 
            // txtage
            // 
            this.txtage.Location = new System.Drawing.Point(371, 219);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(166, 20);
            this.txtage.TabIndex = 10;
            // 
            // txtbmI
            // 
            this.txtbmI.Location = new System.Drawing.Point(371, 273);
            this.txtbmI.Name = "txtbmI";
            this.txtbmI.Size = new System.Drawing.Size(166, 20);
            this.txtbmI.TabIndex = 11;
            // 
            // txtfees
            // 
            this.txtfees.Location = new System.Drawing.Point(371, 325);
            this.txtfees.Name = "txtfees";
            this.txtfees.Size = new System.Drawing.Size(166, 20);
            this.txtfees.TabIndex = 12;
            // 
            // txtjoiningdate
            // 
            this.txtjoiningdate.Location = new System.Drawing.Point(371, 363);
            this.txtjoiningdate.Name = "txtjoiningdate";
            this.txtjoiningdate.Size = new System.Drawing.Size(166, 20);
            this.txtjoiningdate.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(182, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(287, 52);
            this.button1.TabIndex = 0;
            this.button1.Text = " Members";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Schoolbook", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(645, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 23);
            this.label7.TabIndex = 15;
            this.label7.Text = "Customer ID";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(832, 299);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(191, 20);
            this.txtSearch.TabIndex = 16;
            // 
            // bynupdatecust
            // 
            this.bynupdatecust.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bynupdatecust.Location = new System.Drawing.Point(352, 426);
            this.bynupdatecust.Name = "bynupdatecust";
            this.bynupdatecust.Size = new System.Drawing.Size(212, 44);
            this.bynupdatecust.TabIndex = 17;
            this.bynupdatecust.Text = "Update Customer";
            this.bynupdatecust.UseVisualStyleBackColor = true;
            this.bynupdatecust.Click += new System.EventHandler(this.bynupdatecust_Click);
            // 
            // btndeletecust
            // 
            this.btndeletecust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndeletecust.Location = new System.Drawing.Point(887, 375);
            this.btndeletecust.Name = "btndeletecust";
            this.btndeletecust.Size = new System.Drawing.Size(166, 44);
            this.btndeletecust.TabIndex = 18;
            this.btndeletecust.Text = "Delete Customer";
            this.btndeletecust.UseVisualStyleBackColor = true;
            this.btndeletecust.Click += new System.EventHandler(this.btndeletecust_Click);
            // 
            // btnsearchcust
            // 
            this.btnsearchcust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchcust.Location = new System.Drawing.Point(671, 375);
            this.btnsearchcust.Name = "btnsearchcust";
            this.btnsearchcust.Size = new System.Drawing.Size(178, 44);
            this.btnsearchcust.TabIndex = 19;
            this.btnsearchcust.Text = "Search Customer";
            this.btnsearchcust.UseVisualStyleBackColor = true;
            this.btnsearchcust.Click += new System.EventHandler(this.btnsearchcust_Click);
            // 
            // grdLoadCustomer
            // 
            this.grdLoadCustomer.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.grdLoadCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdLoadCustomer.Location = new System.Drawing.Point(578, 12);
            this.grdLoadCustomer.Name = "grdLoadCustomer";
            this.grdLoadCustomer.Size = new System.Drawing.Size(591, 263);
            this.grdLoadCustomer.TabIndex = 20;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1024, 426);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 43);
            this.button2.TabIndex = 21;
            this.button2.Text = "Exit to menu";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1181, 487);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.grdLoadCustomer);
            this.Controls.Add(this.btnsearchcust);
            this.Controls.Add(this.btndeletecust);
            this.Controls.Add(this.bynupdatecust);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtjoiningdate);
            this.Controls.Add(this.txtfees);
            this.Controls.Add(this.txtbmI);
            this.Controls.Add(this.txtage);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnaddmember);
            this.Controls.Add(this.button1);
            this.Name = "Customer";
            this.Text = "NewMember";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Customer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdLoadCustomer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnaddmember;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.TextBox txtbmI;
        private System.Windows.Forms.TextBox txtfees;
        private System.Windows.Forms.TextBox txtjoiningdate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button bynupdatecust;
        private System.Windows.Forms.Button btndeletecust;
        private System.Windows.Forms.Button btnsearchcust;
        private System.Windows.Forms.DataGridView grdLoadCustomer;
        private System.Windows.Forms.Button button2;
    }
}