﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ZN_GYM_Management_System
{
    public partial class Expenses : Form
    {
        public Expenses()
        {
            InitializeComponent();
        }

        private void btnaddexpenses_Click(object sender, EventArgs e)
        {
            int Machine_ID = int.Parse(txtMachineID.Text);
            int Price = int.Parse(txtPrice.Text);
            string Datee = txtDatee.Text;
            BAL.Expenses_Machine expense1 = new BAL.Expenses_Machine(Machine_ID, Price, Datee);
            try
            {
                DAL.DatabaseQuries.AddExpenses(expense1);
                MessageBox.Show("Added Sucessfully");
            }
            catch(Exception)
            {
                MessageBox.Show("Can't Add");
            }
        }

        private void btnSearchMachine_Click(object sender, EventArgs e)
        {
            int machine_ID = int.Parse(txtMachineID.Text);
            if (txtMachineID.Text == "")
            {
                MessageBox.Show("Please Enter Data!");
            }
            else
            {
                string str = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlConnection connection = new SqlConnection(str);
                string q = "if exists (SELECT Machine_ID FROM T_Equipment WHERE Machine_ID = '" + int.Parse(txtMachineID.Text) + "')SELECT Machine_ID FROM T_Equipment else SELECT '0';";
                connection.Open();
                SqlCommand cmd = new SqlCommand(q, connection);
                cmd.ExecuteScalar();


                string returnValue = cmd.ExecuteScalar().ToString();
                if (returnValue == "0")
                {
                    MessageBox.Show("Machine Does Not Exist!");
                }
                else
                {
                    MessageBox.Show("Machine Exists,Enter The Values");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtSearchDate.Text != "")
            {

                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;

                cmd.CommandText = "SELECT * FROM Expenses WHERE Datee = '" + txtSearchDate.Text + "'";
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                grdLoadExpenses.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Please enter here some id", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
            
        }

        private void Expenses_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = "Data Source = DESKTOP-8MUKUTD; Initial Catalog = GYM; Integrated Security = True;";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;

            cmd.CommandText = "SELECT * FROM Expenses;";
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            grdLoadExpenses.DataSource = ds.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Main m1 = new Main();
            m1.Show();
        }
    }
}
