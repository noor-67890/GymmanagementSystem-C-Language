﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZN_GYM_Management_System.BAL
{
    class Employeee
    {
        protected int Employee_ID;
        protected string Employee_Name;
        protected string CNIC;
        protected int Age;
        protected string Phone_No;
        protected string Address;
        protected int Salary;
        protected string Date_Of_Hire;

        public int employee_ID { get; set; }
        public string employee_Name { get; set; }
        public string cnic { get; set; }
        public int age { get; set; }
        public string phone_No { get; set; }
        public string address { get; set; }
        public int salary { get; set; }
        public string date_Of_Hire { get; set; }

        public Employeee(int Employee_ID,string Employee_Name,string CNIC,int Age,string Phone_No,string Address,int Salary,string Date_Of_Hire)
        {
            this.Employee_ID = Employee_ID;
            this.Employee_Name = Employee_Name;
            this.CNIC = CNIC;
            this.Age = Age;
            this.Phone_No = Phone_No;
            this.Address = Address;
            this.Salary = Salary;
            this.Date_Of_Hire = Date_Of_Hire;
        }
    }
}
