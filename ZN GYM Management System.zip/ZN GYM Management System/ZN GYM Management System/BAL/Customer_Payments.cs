﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZN_GYM_Management_System.BAL
{
    class Customer_Payments
    {
        public int Customer_ID { get; set; }
        public int Price { get; set; }
        public string Payment_Date { get; set; }

        public Customer_Payments(int customer_ID,int price,string payment_Date)
        {
            Customer_ID = customer_ID;
            Price = price;
            Payment_Date = payment_Date;
        }
    }
}
