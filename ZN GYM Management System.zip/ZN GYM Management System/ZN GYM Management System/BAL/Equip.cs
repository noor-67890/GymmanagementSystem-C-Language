﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZN_GYM_Management_System.BAL
{
    class Equip
    {
        public int Machine_ID { get; set; }
        public string Machine_Name { get; set; }
        public int Price { get; set; }
        public int No_Of_Machines { get; set; }
        public string Installing_Date { get; set; }
        //private Expenses_Machine exp;

        public Equip(int machine_ID,string machine_Name,int price,int no_Of_Machines,string installing_Date)
        {
            Machine_ID = machine_ID;
            Machine_Name = machine_Name;
            Price = price;
            No_Of_Machines = no_Of_Machines;
            Installing_Date = installing_Date;
        }

    }
}
