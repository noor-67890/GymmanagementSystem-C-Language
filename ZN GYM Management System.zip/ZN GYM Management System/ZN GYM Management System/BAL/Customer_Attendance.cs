﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZN_GYM_Management_System.BAL
{
    class Customer_Attendance
    {
        public int Customer_ID { get; set; }
        public string Datee { get; set; }
        public string Statuss { get; set; }

        public Customer_Attendance(int customer_ID,string datee,string statuss)
        {
            Customer_ID = customer_ID;
            Datee = datee;
            Statuss = statuss;
        }
    }
}
