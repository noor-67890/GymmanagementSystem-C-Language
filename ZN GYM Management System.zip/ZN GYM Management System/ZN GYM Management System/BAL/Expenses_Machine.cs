﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZN_GYM_Management_System.BAL
{
    class Expenses_Machine
    {
        public int Machine_ID { get; set; }
        public int Price { get; set; }
        public string Datee { get; set; }

        public Expenses_Machine(int machine_ID,int price,string datee)
        {
            Machine_ID = machine_ID;
            Price = price;
            Datee = datee;
        }
        
    }
}
