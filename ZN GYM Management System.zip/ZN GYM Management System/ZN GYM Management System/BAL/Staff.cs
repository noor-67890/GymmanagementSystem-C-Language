﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZN_GYM_Management_System.BAL
{
    class Staff : Employeee 
    {
        public string Job_Destination { get; set; } 

        public Staff( int Employee_ID, string Employee_Name, string CNIC, int Age, string Phone_No, string Address, int Salary, string Data_Of_Hire,string Job_Destination) : base(Employee_ID,Employee_Name,CNIC,Age,Phone_No,Address,Salary,Data_Of_Hire)
        {
            this.Job_Destination = Job_Destination;
        }
        
    }
}
