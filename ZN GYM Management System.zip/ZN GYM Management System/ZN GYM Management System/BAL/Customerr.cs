﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZN_GYM_Management_System.BAL
{
    class Customerr
    {
        public int Customer_ID { get; set; }
        public string Customer_Name { get; set; }
        public int Age { get; set; }
        public int BMI { get; set; }
        public int Fees { get; set; }
        public string Joining_Date { get; set; }

        public Customerr(int customer_ID,string customer_Name,int age,int bmi,int fees,string joining_Date)
        {
            Customer_ID = customer_ID;
            Customer_Name = customer_Name;
            Age = age;
            BMI = bmi;
            Fees = fees;
            Joining_Date = joining_Date;
        }
    }
}
